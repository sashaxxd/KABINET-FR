<?php
/**
 * Created by PhpStorm.
 * User: alex_pc
 * Date: 13.12.2017
 * Time: 14:34
 */

namespace app\models;


class Spec extends \yii\db\ActiveRecord
{
    public static function tableName()
    {
        return 'spec';
    }

}