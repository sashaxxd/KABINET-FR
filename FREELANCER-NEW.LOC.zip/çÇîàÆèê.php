<?php
/**
 1 СТАВИМ RBAC https://github.com/mdmsoft/yii2-admin
 php composer.phar require mdmsoft/yii2-admin "~2.0"
 */

